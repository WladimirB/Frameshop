-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 03 2020 г., 21:21
-- Версия сервера: 5.6.38-log
-- Версия PHP: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `frameshop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `short_description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int(10) DEFAULT NULL,
  `full_description` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `price`, `short_description`, `image`, `count`, `full_description`) VALUES
(1, 'ASUS', 27000, 'обЪём оперативной памяти 6ГБ', 'asus_vivobook.jpg', 3, 'asus.txt'),
(2, 'HP15-rb000', 17000, 'объём оперативной памяти 4ГБ', 'HP 15-rb000.jpg', 5, 'hp-15.txt'),
(3, 'HP17--ca000', 25000, 'Тип памяти DDR4, игровой', 'HP 17-ca0000.jpg', 4, 'hp-17.txt'),
(4, 'Lenovo', 15006, 'Недорогая модель', 'Lenovo.jpg', 8, 'lenovo.txt'),
(9, 'HP Pavilion 17-cd', 31000, 'Шмрокийэкран', 'HP_PAVILION_17-cd.jpg', 12, 'HP_PAVILION_17-cd.txt'),
(10, 'ACER Aspire 3', 14400, 'недорогой ноутбук', 'ACER Aspire 3.jpeg', 12, 'ACER_Aspire_3.txt'),
(11, 'APPLE MacBook air', 80800, 'Качественный , дорогой бренд', 'APPLE_MacBook _Air.jpeg', 3, 'APPLE_MacBook_Air.txt'),
(12, 'Dell G3 3590', 37560, 'Средний цена-качество', 'DELL G3 3590.jpeg', 26, 'DELL_G3_3590.txt'),
(13, 'HONOR MAGiKBook 14', 14500, 'недорогой и среднего качества', 'HONOR_MagicBook_14.jpeg', 15, 'HONOR_MagicBook_14.txt'),
(14, 'Lenovo ThinkPad T480', 32456, 'Страна производитель КНР', 'LENOVO_ThinkPad_T480.jpeg', 22, 'LENOVO_ThinkPad_T480.txt'),
(15, 'Dolphin', 555, 'test', 'img1.jpg', 8, 'описания нет'),
(16, 'three', 23, 'test', 'img5.jpg', 3, 'описания нет'),
(18, 'ACER Aspire 3', 27000, 'test', 'ACER Aspire 3.jpeg', 9, 'описания нет');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `count` int(5) NOT NULL,
  `good_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `count`, `good_id`, `user_id`, `date`) VALUES
(1, 2, 1, 2, '0000-00-00 00:00:00'),
(2, 2, 3, 3, '0000-00-00 00:00:00'),
(3, 1, 1, 2, '2020-06-02 19:33:41'),
(4, 1, 16, 2, '2020-06-02 19:33:41');

-- --------------------------------------------------------

--
-- Структура таблицы `temp_orders`
--

CREATE TABLE `temp_orders` (
  `id` int(11) NOT NULL,
  `count` int(5) NOT NULL,
  `good_id` int(11) NOT NULL,
  `user_name` int(11) NOT NULL,
  `phone` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(70) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(70) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `email`, `role`) VALUES
(1, 'Natsu', 'Dragnill', NULL, 1),
(2, 'Gray', 'Fullbuster', NULL, 1),
(3, 'Somebody', 'Everybody', NULL, 1),
(4, 'admin', 'admin', NULL, 3),
(5, 'Master1', '$2y$09$ufq7AQT25U.0laKmokvrTOunXv2aWHirKdMJeKddXQZK2LHSxCgRa', 'zasran@mail.su', 1),
(6, 'Valera', '$2y$09$HdMLeYU1cdV2rrrGPmRXBuy/ScctsYOkiPZjQJcnZIoAsLqkkH1lu', 'zasran@mail.su', 1),
(7, 'Kopyiss', '$2y$09$/JLhkB.cQm6Qv2xj0DltE.tQOaXpFBKQs8zgf8U1eec9rtMgSuVS2', 'zasran@mail.su', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `good_id` (`good_id`);

--
-- Индексы таблицы `temp_orders`
--
ALTER TABLE `temp_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `good_id` (`good_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `password` (`password`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `temp_orders`
--
ALTER TABLE `temp_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`good_id`) REFERENCES `goods` (`id`);

--
-- Ограничения внешнего ключа таблицы `temp_orders`
--
ALTER TABLE `temp_orders`
  ADD CONSTRAINT `temp_orders_ibfk_1` FOREIGN KEY (`good_id`) REFERENCES `goods` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
