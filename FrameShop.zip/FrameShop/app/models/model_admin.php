<?php

class Model_Admin extends Model
{

public function getOrders(){
  $query = "SELECT a.id'номер',b.name'наименование',a.count'количество',c.login'имя'
   FROM `orders` a
   INNER JOIN `goods`b ON a.good_id=b.id
  INNER JOIN `users`c ON a.user_id=c.id";
  $result=$this->pdo->prepare($query);
  $result->execute();
  $data=$result->fetchAll();
  return $data;
 }

   public function update($table,$assoc){
     $placeholders =[];
     $id=$assoc['id'];
     unset($assoc['id']);
     foreach($assoc as $key => $value ){
       $placeholders[]="$key=:$key";
       if($value === NULL){
         $placeholders[$key]='NULL';
       }
     }

     $placeholders_s=implode(',',$placeholders);
     $query = "UPDATE $table SET $placeholders_s WHERE id=$id";
     $stmt = $this->pdo->prepare($query);
     $stmt->execute($assoc);
     if ($stmt->errorCode() != PDO::ERR_NONE) {
  				$info = $stmt->errorInfo();
  				die($info[2]);
  			}
    	return 'Изменено '.$placeholders_s.' id '.$id;

   }

}
