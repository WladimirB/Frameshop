<?php

class Model_Catalog extends Model
{

  public function __construct()
  {
    parent::__construct();
    parent::setLimit(3);
  }

}
