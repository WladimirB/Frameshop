<?php

class Model_Register extends Model{

 public function checktUser(array $data)
 {
   $stmt = $this->pdo->prepare('SELECT id FROM users WHERE login=?');
   $stmt->execute(array($data['login']));
   $id=$stmt->fetch();
   $res=(!empty($id))?'Пользователь с таким логином уже существует':NULL;
   return $res;
 }

}
