<?php

class Model_Basket extends Model
{
  
}
