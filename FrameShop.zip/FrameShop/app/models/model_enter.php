<?php

 class Model_Enter extends Model
 {
   private $login;
   private $password;


   public function __construct(){
    parent::__construct();
    $this->login =  $_POST['login'];
    $this->password= $_POST['password'];
   }

   public function checkUser(){
     $query = 'SELECT id,login,role FROM users WHERE login= :login  AND password = :password';
     $result = $this->pdo->prepare($query);
     $result->bindParam(':login', $this->login,PDO::PARAM_STR);
     $result->bindParam(':password', $this->password,PDO::PARAM_STR);
     $result->execute();
     $data=$result->fetch();
     return $data;
   }

 }
