<?php
class Controller_Basket extends Controller
{
  public function __construct()
  {
    $this->view = new View();
    $this->model= new Model_Basket();
  }

  public function action_index()
  {
    if (isset($_SESSION['Basket'])) {
      $products=$_SESSION['Basket'];
      $produtsId=array_keys($products);
      $data = array_map('Model::getItemById',$produtsId);
      //$data=array_combine($products,$data);
      foreach ($products as $key => $value) {
        for($i=0;$i<count($data);$i++){
        if($data[$i]['id']==$key){
          $data[$i]['count']=$value;
        }
       }
      }
      $cost=[];
      $cost['totalCount']=Basket::getCount();
      $cost['totalPrice']=$this->getTotalPrice($data);
      $this->view->display('basket',$this->view->basketInflate($data),$cost);
    }
    else {
      $this->view->display('post','Корзина пуста');
    }
  }

  public function action_add(){
    if (isset($_SESSION['user']) && isset($_SESSION['Basket'])) {
      $date = date("Y-m-d H:i:s");
      $order=[];
      $data=[];
      foreach ($_SESSION['Basket'] as $key => $value) {
        $order['count']=$value;
        $order['good_id']=$key;
        $order['user_id']=$_SESSION['user']['id'];
        $order['date']=$date;
        $data[]=$this->model->insert('orders',$order);
      }
        $data='Номер вашего заказа:'.implode(',',$data);
        unset($_SESSION['Basket']);
    }
    else{
      $data='Чтобы оформить заказ,нужно авторизоваться';
    }
    $this->view->display('post',$data);
  }

  public function action_delete($id)
    {
        unset($_SESSION['Basket'][$id]);
        if (empty($_SESSION['Basket'])) {
          unset($_SESSION['Basket']);
        }
        header("Location: /basket");
    }

  public function action_clean(){
    unset($_SESSION['Basket']);
    echo 'корзина очищена';
  }

  public function action_ajax(){
    if ( $_SERVER['REQUEST_METHOD']=='POST'){
      $id=intval($_POST['data']);
      $productInCart=[];
      if (isset($_SESSION['Basket'])) {
        $productInCart=$_SESSION['Basket'];
      }
      if (array_key_exists($id,$productInCart)){
        $productInCart[$id]++;
      }
      else {
        $productInCart[$id]=1;
      }
      $_SESSION['Basket']=$productInCart;
      $response= $id;
      echo $response;
    }
  }

  private function getTotalPrice($products)
     {
       $total = 0;
       $productsInCart = Basket::getCount();
       if ($_SESSION['Basket']) {
          $productInCart=$_SESSION['Basket'];
           foreach ($products as $item) {
               $total += $item['price'] * $productInCart[$item['id']];
           }
       }

       return $total;
   }

}
