<?php

class Controller_Register extends Controller{
   private $form;


   public function __construct(){
     $this->view=new View;
     $this->model = new Model_Register();
   }

   public function action_index(){
     $data = 'Регистрация нового пользователя';
     $this->view->display('register',$data);
   }

   public function action_post(){
     $this->form = new Form_Validator($_POST);
     $result = $this->form->getResultValid();
     if($result != 'incorrect') {
     $data=$this->model->checktUser($result);
     if(!$data){
       $data=$this->model->insert('users',$result);
       $data='Вы успешно зарегистрировались,ваш Id:'.$data;
      }
     }
     else {
       $data = 'Регистрация невозможна';
     }
     $this->view->display('post', $data);
   }

   public function action_ajax(){
     $ajax_data = json_decode($_POST['valid'],true);
     $response_data = Form_Validator::ajaxValidField($ajax_data);
     echo json_encode($response_data);
   }

}
