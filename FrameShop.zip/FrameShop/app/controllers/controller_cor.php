<?php
include dirname(__DIR__).'./models/model_catalog.php';

  class Controller_Cor extends Controller
  {
    public function action_index(){

        header('Access-Control-Allow-Origin: http://localhost:9000');
        header('Access-Control-Allow-Methods: GET,POST,PUT,DELETE');
        header('Access-Control-Allow-Crenditals: true');
        header('Access-Control-Allow-Headers: Autorization, Origin, X-Request-With, Accept, Content-Type');
        $model=new Model_Catalog();
        $count = $model->getCount('goods');
        $data = ceil($count/$model->getLimit());
        echo $data;
      }

    public function action_page($page=1){
      header('Access-Control-Allow-Origin: http://localhost:9000');
      header('Access-Control-Allow-Methods: GET,POST,PUT,DELETE');
      header('Access-Control-Allow-Crenditals: true');
      header('Access-Control-Allow-Headers: Autorization, Origin, X-Request-With, Accept, Content-Type');
      $model=new Model_Catalog();
      $limit=$model->getLimit();
      $offset = ($page*$limit)-$limit;
      $result = $model->getData('goods',$offset);
      foreach ($result as $key => $value) {
        $result[$key]['path']=$this->imgEncode($value['image']);
      }

      $data=json_encode($result);
      echo $data;
    }

    public function action_search(){
      header('Access-Control-Allow-Origin: http://localhost:9000');
      header('Access-Control-Allow-Methods: GET,POST,PUT,DELETE');
      header('Access-Control-Allow-Crenditals: true');
      header('Access-Control-Allow-Headers: Autorization, Origin, X-Request-With, Accept, Content-Type');
      if(isset($_POST)){
        preg_match('{^[A-Z]*[a-z0-9]*-?[A-Z]?[a-z]*[0-9]*$}s',$_POST['search'],$matches);
        if(!empty($matches)){
            $data = $matches[0];
            $model=new Model_Catalog();
            $result = $model->searchItems('goods',null,null,$data);
            foreach ($result as $key => $value) {
             $result[$key]['path']=$this->imgEncode($value['image']);
            }
          }
         else{
           $result = "Такого товара не существует";
         }
        echo json_encode($result);
      }
    }


    private function imgEncode($file) {
      $path = '.'.FileManager::createSrc($file);
      $img = getimagesize($path);
      $imgBuff=base64_encode(file_get_contents($path));
      $imgSrc="data:{$img['mime']};base64,{$imgBuff}";
      return $imgSrc;
    }
  }
