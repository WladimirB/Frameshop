<?php

Class Controller_User extends Controller{

   public function __construct()
   {
      $this->view = new View();
   }

  public function action_index(){
    $id = $_SESSION['user']['id'];
    $this->view->display('user',$id);
  }

 public function action_logout(){
    unset($_SESSION['user']);
    $this->view->display('post','Выход выполнен');
  }

}
