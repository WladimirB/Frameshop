<?php
  Class Controller_Admin extends Controller
  {
    private $limit;
    private $nav;
    private $fields;

     public function __construct()
     {
        $this->view = new View();
        $this->model = new Model_Admin();
        $this->fields=array('id','name','price','count');
        $count=$this->model->getCount('goods');
        $this->limit=$this->model->getLimit();
        $this->nav = new NavBuilder($count,'/admin/list/',$this->limit,2);
     }

    public function action_index(){
      $id = $_SESSION['user']['id'];
      $this->view->display('admin',$id);
    }

   public function action_orders(){
       $result = $this->model->getOrders();
       $data = $this->view->arrExpand($result);
       $this->view->display('orderlist',$data);
   }

   public function action_list($page){
       $offset = ($page*$this->limit)-$this->limit;
       $this->nav->setCurrentPage($page);
       $links['nav']=$this->nav->buildNav();
       $result = $this->model->getData('goods',$offset,$this->fields);
       $data=$this->view->format($result);
       $this->view->display('goodslist',$data,$links);
   }

   public function action_add()
   {
     if (@$_REQUEST['submit']) {
       $dataInsert = array('name' => '',
                           'price' => '',
                           'short_description' => '',
                           'image' => '',
                            'count' => '',
                            'full_description' => '');
      foreach($_POST as $key => $value){
        if(array_key_exists($key,$dataInsert)){
          $dataInsert[$key]=$value;
          unset($key);
        }
      }
       $handleImage=new Image();
       $dataInsert['image'] = $handleImage->createImage();
       if (is_file($_FILES['full_description']['tmp_name'] && $_FILES['full_description']['type'] ==='txt')) {
         $dataInsert['full_description']=$_FILES['full_description']['name'];
         move_uploaded_file($_FILES['full_description']['tmp_name'],'./'.FileManager::getPath($dataInsert['full_description']));
       }
       else {
           $dataInsert['full_description']='описания нет';
       }
       $result = $this->model->insert('goods',$dataInsert);
       $data = 'Добавлен новый товар под номером:'.$result.$_FILES['full_description']['name'];
       $this->view->display('post',$data);
     }
     $this->view->display('add');
   }

   public function action_logout(){
      unset($_SESSION['user']);
      $this->view->display('post','Выход выполнен');
    }

  public function action_ajax(){
    if( $_SERVER['REQUEST_METHOD'] == 'POST'){
      $headers = apache_request_headers();
        $request = 'false';
        if(is_object(json_decode($_POST['data'])) || is_array(json_decode($_POST['data']))){
          $request =json_decode($_POST['data'],true);
        }
        else{
          $request=$_POST['data'];
        }
      $query =$headers['admin'];
      $response = call_user_func_array(array($this->model,$query),array('goods',$request));

    }
        echo '<strong>',$response,'</strong>';
  }


}
