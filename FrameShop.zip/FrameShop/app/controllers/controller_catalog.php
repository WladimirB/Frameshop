<?php

class Controller_Catalog extends Controller
{
    private $links;
    private $limit;

    public function __construct()
    {
      $this->view = new View;
      $this->model = new Model_Catalog;
      $this->limit = $this->model->getLimit();

    }

    public function action_index()
    {
      $this->view->display('catalogWithReact');
      //$this->action_getLinks();
    }

    public function action_getLinks($page=1){
      $count = $this->model->getCount('goods');
      $limit=$this->model->getLimit();
      $countPages = ceil($count/$limit);
      $navBuilder = new NavBuilder($count,'/catalog/getLinks/',$limit,2);
      $navBuilder->setCurrentPage($page);
      $this->links['page']=$page;
      $this->links['nav']=$navBuilder->buildNav();
      $offset = ($page*$this->limit)-$this->limit;
      $data=$this->model->getData('goods',$offset);
      $this->view->display('catalog',$data,$this->links);
      ///echo $data;
    }

    public function action_page($page=1)
    {
      $offset = ($page*$this->limit)-$this->limit;
      $result=$this->model->getData('goods',$offset);
      foreach ($result as $key => $value) {
        $result[$key]['path']=$this->imgEncode($value['image']);
      }
      $data=json_encode($result);
      echo $data;
    }

    public function action_product($id,$page)
    {
      $dataInfo = Model::getItemById($id);
      $desc = FileManager::getPath($dataInfo['full_description']);
      if (is_file($desc)) {
        $dataInfo['info']=file($desc);
      }
      else {
        $dataInfo['info']=$dataInfo['full_description'];
      }
      $dataInfo['page']=$page;
      $this->view->display('product',$dataInfo);
    }

    public function action_search(){
      if(isset($_POST)){
        preg_match('{^[A-Z]*[a-z0-9]*-?[A-Z]?[a-z]*[0-9]*$}s',$_POST['search'],$matches);
        if(!empty($matches)){
            $data = $matches[0];
            $model=new Model_Catalog();
            $result = $model->searchItems('goods',null,null,$data);
            foreach ($result as $key => $value) {
             $result[$key]['path']=$this->imgEncode($value['image']);
            }
          }
         else{
           $result = "Такого товара не существует";
         }
        echo json_encode($result);
        //$this->view->display('catalog',$result);
      }
    }

    private function imgEncode($file) {
      $path = '.'.FileManager::createSrc($file);
      $img = getimagesize($path);
      $imgBuff=base64_encode(file_get_contents($path));
      $imgSrc="data:{$img['mime']};base64,{$imgBuff}";
      return $imgSrc;
    }

}
