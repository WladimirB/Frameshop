<?php

  class Controller_Enter extends Controller{

     public function __construct(){
       $this->view = new View();
     }

     public function action_index(){
       $this->view->display('enter');
     }

     public function action_post(){
       if (isset($_POST)){
         $this->model = new Model_Enter();
       }
       $result = $this->model->checkUser();
       if ($result) {
       $user = ($result['role'] === 3)?'Admin':'User';
       $result['role']=$user;
       unset($this->model);
       $_SESSION['user']=$result;
       Router::redirect('Controller_'.$user);
       }
       else {
         $data = 'такого пользователя не существует';
         Router::redirect('Controller_Register');
       }
      }


     public static function action_logout(){
        unset($_SESSION['user']);
        Router::redirect('Controller_Enter');
      }

    public function action_isLogin(){
      if (isset($_SESSION['user'])) {
        echo $_SESSION['user']['id'];
      }
      else {
       header('HTTP/1.1 404 Not Found');
   		 //header("Status: 404 Not Found");
      }
    }
}
