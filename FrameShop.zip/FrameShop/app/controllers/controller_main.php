<?php

class Controller_Main extends Controller
{

	function action_index()
	{
	  $data ='Однажды Арнольд сказал: "I\'ll be back"';
		$this->view->display('entrance',$data);
	}

}
