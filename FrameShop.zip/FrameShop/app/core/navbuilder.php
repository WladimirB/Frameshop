<?php
class NavBuilder
{
  private $count=null;
  private $pages=null;
  private $uri = null;
  private $current_page=1;
  private $spread =null;
  private $activeClass ='Current';

  public function __construct($count,$uri,$limit,$spread)
  {
    $this->count=$count;
    $this->uri=$uri;
    $this->pages=ceil($this->count/$limit);
    $this->spread = $spread;
  }

  public function setCurrentPage($page)
  {
    $this->current_page=intval($page);
  }

  public function buildNav()
  {  $links='';
     $shift_start = max($this->current_page - $this->spread,2);
      $shift_end = min($this->current_page+$this->spread,($this->pages-1));
      if ($shift_end < $this->spread*2){
        $shift_end = min($this->spread*2,($this->pages-1));
        }
      if ($shift_end == ($this->pages-1) && $shift_start>3 ){
      $shift_start = max(3,min($this->pages - $this->spread*2+1,$shift_start) );
       }
      $links.=$this->addHref(1);

      if ($shift_start == 3) {
         $links.=$this->addHref(2);
      } elseif ($shift_start > 3) {
         $links.='<li>...</li>';
      }

      for($i=$shift_start;$i<=$shift_end;$i++){
        $links.=$this->addHref($i);
      }

      $last_page = $this->pages-1;
      if ( $shift_end == $last_page-1 ){
        $links.=$this->addHref($last_page);
      } elseif ($shift_end < $last_page) {
        $links.='<li>...</li>';
      }

     $links.=$this->addHref($this->pages);
     return $links;
 }

 private function addHref($num_page,$page_name='',$className=false){
   $page_name = $page_name ?: $num_page;
   $className = $className ? '' : $this->activeClass;
   if ($this->current_page == $num_page){
     return "<li><a class= {$className} href=#>{$page_name}</a></li>";
   }
   return "<li><a href=$this->uri{$num_page}>{$num_page}</a></li>";
 }

}
