<?php

final class Basket
{
  private function __construct(){}
  private function __clone(){}

  public static function getCount(){
    $countInBasket=0;
    if (isset($_SESSION['Basket'])) {
      foreach ($_SESSION['Basket'] as $key => $value) {
        $countInBasket+=$value;
      }
    }
    return $countInBasket;
  }
}
