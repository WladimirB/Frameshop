<?php

class CalcRatio
{
  private $width;
  private $height;
  private $ratio;
  private $outWidth;
  private $outHeight;
  private $marginY = 0;
  private $marginX = 0;

  public function __construct(array $metrix){
    list($this->width,$this->height,$this->outWidth,$this->outHeight)=array_values($metrix);
    $this->ratio = $this->width/$this->height;
  }

  private function calc(){
    if($this->ratio > 1){
      $this->marginY = (int)(($this->outHeight - ($this->outHeight/$this->ratio))/2);
      $this->outHeight=(int)($this->outHeight/$this->ratio);
    }
    elseif($this->ratio < 1 ){
      $this->marginX = (int)(($this->outWidth - ($this->outWidth*$this->ratio))/2);
      $this->outWidth = (int)($this->outWidth*$this->ratio);
    }
    elseif ($this->ratio == 1) {
    return;
    }
  }


  public function getMetrix(){
    $this->calc();
    return array($this->marginX,$this->marginY,0,0,$this->outWidth,$this->outHeight);
  }
}
