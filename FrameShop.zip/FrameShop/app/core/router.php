<?php

class Router
{
    private static $route;

    static function start()
    {

      $controller_name = 'Main';
  		$action_name = 'index';

  		$routes = explode('/', $_SERVER['REQUEST_URI']);

  		// получаем имя контроллера
  		if ( !empty($routes[1]) )
  		{
  			$controller_name = $routes[1];
  		}

  		// получаем имя экшена
  		if ( !empty($routes[2]) )
  		{
  			$action_name = $routes[2];
  		}
      $param=array(' ');
      if (count($routes)>3){
        $param = array_slice($routes,3);
      }


  		// добавляем префиксы
  		$model_name = 'Model_'.$controller_name;
  		$controller_name = 'Controller_'.$controller_name;
  		$action_name = 'action_'.$action_name;


  		// подцепляем файл с классом модели (файла модели может и не быть)

  		/*$model_file = strtolower($model_name).'.php';
  		$model_path = "app/models/".$model_file;
  		if(file_exists($model_path))
  		{
  			include $model_path;
  		}*/

     self::getClass($model_name,'app/models/');

     self::getClass($controller_name);

     $controller = new $controller_name;

     $action = $action_name;

     if(method_exists($controller,$action)){
       //$controller->$action();
       call_user_func_array(array($controller,$action),$param);
     }
     else {
       Router::ErrorPage404();
     }

    }

    static function ErrorPage404()
    {
      echo "ошибка";

     /*$host = 'http://'.$_SERVER['HTTP_HOST'].'/';
     header('HTTP/1.1 404 Not Found');
		 header("Status: 404 Not Found");
		 header('Location:'.$host.'404');*/
    }

    public static function redirect($controller){
      self::getModelClass($controller);
      self::getClass($controller);
      $controller= new $controller();
      $controller->action_index();
    }
    private static function getModelClass($class)
    {
      $class=str_replace('Controller','Model',$class);
      $class_file=strtolower($class).'.php';
      $class_path='app/models/'.$class_file;
      if(file_exists($class_path))  {
        include_once $class_path;
      }
    }
    public static function getClass($class,$path='app/controllers/'){
      $class_file=strtolower($class).'.php';
      $class_path=$path.$class_file;
      if (file_exists($class_path)){
      include_once $class_path;
      }
    }

}
