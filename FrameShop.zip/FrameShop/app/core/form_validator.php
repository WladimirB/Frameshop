<?php

class Form_Validator
{
  private $input_data;
  private $checked_data = [];
  private static $rules=RULES;
  private static $answer= ANSWERS;
  private $valid = false;

  public function __construct(array $input_data)
  {
    $this->input_data = $input_data;
  }

  public static function ajaxValidField($ajax_data){
   $key=key($ajax_data);
   preg_match(self::$rules[$key],$ajax_data[$key],$matches);
   if(!$matches){
      $ajax_data[$key]=self::$answer[$key];
   }
   else {
     $ajax_data[$key]='ок';
   }
   return $ajax_data;
  }

 public function getResultValid(){
   $this->checkData();
   $this->valid();
   if($this->valid==='well'){
     return $this->checked_data;
   }
   else{
     return $this->valid;
   }
 }

  private function checkData() //основная функция валидации
  {
   foreach ($this->input_data as $key => $value) {
     if(array_key_exists($key,self::$rules)) //проверка есть ли правило для валидации,как вариант можно сразу обрезать submit
     {
      preg_match(self::$rules[$key],$value,$matches);
      if(!$matches) {
        $this->checked_data[$key]='error';
      }
      else {
      $this->checked_data[$key]=$matches[0];
     }
    }
   }
 }

 private function valid(){
       if(in_array('error',$this->checked_data)){
         $this->valid='incorrect';
         $this->hadError();
       }
       else{
         $this->valid = 'well';
         $this->checked_data['password']=password_hash($this->checked_data['password'],PASSWORD_BCRYPT,['cost'=>9]);
       }
 }

 private function hadError(){
     foreach($this->checked_data as $key => $value){
       if($value == 'error'){
        $this->checked_data[$key]=self::$answer[$key];
       }
     }
 }

}
