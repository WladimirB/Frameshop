<?php

class Model
{
  protected $pdo;
  protected  $limit=8;

  public function __construct(){
    $this->pdo=DBConnect::getInstance();
  }

  public function getData($table,$offset=null,array $fields=null)
  {
    $offset=intval($offset);
    if ($fields != null){
      $columns=implode(',',array_values($fields));
    }
    else {
      $columns='*';
    }
    $query = "SELECT $columns FROM $table ORDER BY id ASC LIMIT :limit OFFSET :offset";
    $stmt=$this->pdo->prepare($query);
    $stmt->execute(array(':limit'=>$this->limit,
                         ':offset'=>$offset));
    $result=$stmt->fetchAll();
    return $result;
  }

  public static function getItemById($id)
  {
    $query = "SELECT*FROM goods WHERE id=:id";
    $stmt =DBConnect::getInstance()->prepare($query);
    $stmt->bindValue(':id',$id,PDO::PARAM_INT);
    $stmt->execute();

    $result=$stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
  }


    public function searchItems($table,$offset=null,array $fields=null,$name){
      $offset=intval($offset);
      if ($fields != null){
        $columns=implode(',',array_values($fields));
      }
      else {
        $columns='*';
      }
      $query = "SELECT $columns FROM $table WHERE name LIKE :name LIMIT :limit OFFSET :offset";
      $stmt=$this->pdo->prepare($query);
      $stmt->execute(array(':name'=>'%'.$name.'%',
                           ':limit'=>$this->limit,
                           ':offset'=>$offset));
      $result=$stmt->fetchAll();
      return $result;
    }

  public function getCount($table)
  {
    $query = "SELECT COUNT(*) FROM $table";
    $stmt = $this->pdo->prepare($query);
    $stmt->execute();
    $count=$stmt->fetchColumn(0);

    return $count;
  }

  public function setLimit($value){
    if (is_integer($value)) {
    $this->limit=$value;
   }
   else {
     return false;
   }
  return true;
  }

  public function getLimit()
  {
    return $this->limit;
  }

  public function insert($table,array $assoc){
    $columns=[];
    $values=[];

    foreach ($assoc as $key => $value){
       $columns[]=$key;
       $values[] = ":$key";

      if($value === NULL){
        $assoc[$key] = 'NULL';
      }
    }

    $columns_s = implode(',', $columns);
    $values_s = implode(',',$values);
    $query = "INSERT INTO $table($columns_s) VALUES ($values_s)";
    $stmt = $this->pdo->prepare($query);
    $stmt->execute($assoc);
    if ($stmt->errorCode() != PDO::ERR_NONE) {
 				$info = $stmt->errorInfo();
 				die($info[2]);
 			}
     return $this->pdo->lastInsertId();
  }

  public function delete($table,$id){
    $query = "DELETE FROM $table WHERE id=$id";
    $stmt = $this->pdo->prepare($query);
    $stmt->execute();
    if ($stmt->errorCode() != PDO::ERR_NONE) {
        $info = $stmt->errorInfo();
        die($info[2]);
      }
    return $id.' позиция из таблицы '.$table.' удалена';
  }

}
