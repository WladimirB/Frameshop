<?php
 include 'filemanager.php';
 include 'calcratio.php';

  class Image extends FileManager
  {
    private  $file=null;
    private $name=null;
    private $create = 'imagecreatefrom';
    private $save = 'image';
    private $extensions = array("","gif","jpeg","png");
    private $Width = null;
    private $Height = null;
    private $reBig = [
                     'widthBig' => 400,
                     'heightBig' => 400,
                   ];
    private $reSmall=[ 'widthSmall' => 200,
                           'heightSmall' => 200,
                          ];//массив размеров после копирования
    public function __construct(){
      //@copy($_FILES['userfile']['tmp_name'],$this->tmp.$_FILES['userfile']['name']);
      $this->reBig[] = parent::$dest[0];
      $this->reSmall[] = parent::$dest[1];
      $this->file=$_FILES['userfile']['tmp_name'];
      $this->name=$_FILES['userfile']['name'];
      list($this->Width,$this->Height,$type) = getimagesize($this->file);
      $ext = $this->extensions[$type];
      if(!$ext){
        return $this->hadError();
        //exit();
      }
      $this->create .=$ext;
      $this->save .= $ext;

    }

   private function resize(array $data){
     list($width,$height,$dest)= array_values($data);
     $metrix = array($this->Width,$this->Height,$width,$height);
     $calc = new CalcRatio($metrix);
     $calc=$calc->getMetrix();
     list($dst_x,$dst_y,$x,$y,$dst_w,$dst_h)=$calc;
     $func=$this->create;
     $img=$func($this->file);
     $img_out = imagecreatetruecolor($width,$height);
     $bg=imagecolorallocatealpha($img_out,43,38,43,186);
     imagefill($img_out,0,0,$bg);
     imagecopyresampled($img_out,$img,$dst_x,$dst_y,$x,$y,$dst_w,$dst_h,$this->Width,$this->Height);
     ///$img_out=imagescale($img,200);
     $func=$this->save;
     $func($img_out,'.'.$dest.$this->name);
     imagedestroy($img_out);
   }

    public function createImage(){
        $this->resize($this->reBig);
        $this->resize($this->reSmall);
        return $this->name;
       }

    private function hadError(){
      return 'Данный файл не может быть обработан';
    }
  }
