<?php

 class FileManager
 {
   static private $description='resized/description/';
   static protected $dest=[
                  '/resized/big/',
                  '/resized/small/'];//пути для сохранения файлов,большие и малые картинки соответсвенно

   private function __construct(){}
   final private function __clone(){}


  final public static function createSrc($img,$f=1) {
      return $path=self::$dest[$f].$img;
      }

  final public static function getPath($file){
    return self::$description.$file;
  }

}
