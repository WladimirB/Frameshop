<?php
require_once (dirname(__FILE__).'/../config/db.php');

final class DBConnect
{
  static private $instance=null;

  private function __construct(){}
  private function __clone(){}

 public static function getInstance(){
       if(self::$instance === null){
             $opt = [
               PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
               PDO::ATTR_DEFAULT_FETCH_MODE =>PDO::FETCH_ASSOC,
               PDO::ATTR_EMULATE_PREPARES => false
             ];
             $dsn = 'mysql:host='.HOST.';dbname='.DATABASE.';charset=utf8';
             self::$instance = new PDO($dsn,USER,PASSWORD,$opt);
       }
       return self::$instance;
}

}
