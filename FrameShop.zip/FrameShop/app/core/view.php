<?php

class View
{
    static public $login_detect ='Вход';
    static public $login_url='/enter';
    static public $user_panel=false;
    static public $user_url=false;
    static public $enter='не выполнен';
    private $template_view = 'app/views/Main.php';

    public function display($content_view,$data=null,$links=null)
    {
      $content_view='app/views/'.$content_view.'.php';
      if(isset($_SESSION['user'])){
        self::$login_detect='Выход';
        self::$login_url='/enter/logout';
        self::$user_url='/'.$_SESSION['user']['role'];
        self::$user_panel=$_SESSION['user']['role'].' panel';
        self::$enter='Пользователь id '.$_SESSION['user']['id'];
      }
      include './'.$this->template_view;
    }

    public  function arrExpand($data){
     $out=' ';
       foreach($data as $key => $part){
          if(is_array($part)){
            $out=$out."<li><span>".implode('</span><span>',$part)."</span>";
            $out=$out."<button id='$key'>обработать</button></li>";
          }
         }
      return $out;
      }

    public function format($data){
       $out='';
       foreach($data as $key => $part){
         if(is_array($part)){
           $out.='<li id='.$part['id'].'>';
           foreach($part as  $key => $value){
           $out.='<span name='.$key.'>'.$value.'</span>';
          }
          $out.='<button data-action="delete">удалить</button>';
          $out.='<button data-action="update">редактировать</button></li>';
         }
       }
       return $out;
    }

    public function basketInflate($data){
      $out='';
      foreach ($data as $key => $part){
        $out.='<li><span>'.$part['count'].'</span><span>'.$part['name'].'</span><span>'.$part['price'].'</span>';
        $out.='<a  class="Delete" href="/basket/delete/'.$part['id'].'" data-action="delete">&#11199;</a></li>';
      }
      return $out;
    }

      public function dataDisplay($data){
        if(is_array($data)){
        $out=' ';
        foreach ($data as $key => $value) {
          if(is_array($value)){
            $value=implode('||',$value);
          }
          $out=$out.$key.' => '.$value."</br>";
        }
        return $out;
      }
      else{
      return $data;
      }
    }
}
