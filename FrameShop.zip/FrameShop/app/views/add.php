<h2>Доваление нового товара</h2>
<a href="/admin">назад</a>
<form name="register" enctype="multipart/form-data"   method="post">
  <span></span>
  <input type="text" name="name" placeholder="название товара" required>
  <span></span>
  <input type="number" name="price" placeholder="цена товара" required>
   <span></span>
  <input type="text"  name="short_description" placeholder="краткое описание" required>
  <span></span>
  <input type="hidden" name="MAX_FILE_SIZE" value="3000000">
  <input type="file" name="userfile" value="выберите файл" required>
  <span></span>
  <input type="text" name="count" placeholder="количество">
  <span></span>
  <input type="file" name="full_description" value="выберите файл .txt">
  <span></span>
  <input type="submit" name="submit" value="добавить товар">
  <span></span>
</form>
