<h2>Каталог</h2>
<form class="search" action="/catalog/search" method="post">
<input type="text" name="search" placeholder="&#128270;Введите имя товара">
<input type="submit" name="submit" value="найти!">
</form>
<div class="Wrap">
  <?php for($i=0,$size=count($data);$i<$size;$i++ ):?>
    <div class="Good">
      <div class="GoodTop">
        <h3>Модель: <?=$data[$i]['name'];?></h3>
      </div>
      <div class="GoodCenter">
        <img src="<?=FileManager::createSrc($data[$i]['image']);?>" alt="<?=$data[$i]['image'];?>">
          <h3>Цена:<?=$data[$i]['price'] ?></h3>
          <span>Краткое описание: <?=$data[$i]['short_description']?></span>
      </div>
        <a class="More" href="/catalog/product/<?=$data[$i]['id'],'/',$links['page']?>">Подробнее</a>
        <a data-action="addToBasket" id="<?=$data[$i]['id']?>" href="#">В корзину</a>
    </div>
  <?php endfor; ?>
  </div>
  <nav class="NavBuilder">
    <ul>
      <?=$links['nav']?>
    </ul>
  </nav>
  <script type="text/javascript" src="/Js/bundle.js">

  </script>
