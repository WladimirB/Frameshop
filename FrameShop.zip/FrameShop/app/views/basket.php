<h2>Корзина заказа</h2>
<div class="List">
  <h3>Имя <?= $a=isset($_SESSION['user'])?$_SESSION['user']['id']:'anonim' ?></h3>
  <hr class="Line">
  <ul>
      <li><span>Коли&#8203;чество</span><span>Название</span><span>Цена</span></li>
      <?php echo $data ?>
  <hr class="Line">
  <li><span>Всего товаров</span></li>
  <li class="Total"><span><?= $links['totalCount']?></span><span>На сумму</span><span><?= $links['totalPrice']?></span></li>
  </ul>
<a href="/basket/add">Оформить заказ</a>  
<a  href="#" onclick="clean()">Очистить корзину</a>
</div>
<script type="text/javascript">
  function clean(){
    let url = 'http://frameshop/basket/clean';

    let xhr = new XMLHttpRequest();
    xhr.open('GET',url,true);
    xhr.send();
    xhr.onload=function(){
      let elem=document.getElementsByClassName('List')[0];
      console.log(elem);
      elem.innerHTML='<li>'+xhr.response+'</li>';
    }
  }
</script>
