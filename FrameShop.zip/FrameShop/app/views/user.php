<h2>Вы вошли как пользователь-id:<?php echo $data ?></h2>
<div class="List">
  <nav>
    <ul>
      <li><a href="/basket">Корзина покупок</a></li>
      <li><a href="/user/logout">Выход</a></li>
    </ul>
  </nav>
</div>
