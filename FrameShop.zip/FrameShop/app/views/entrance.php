<h2>Добро пожаловать</h2>
<?php
 echo $data;
