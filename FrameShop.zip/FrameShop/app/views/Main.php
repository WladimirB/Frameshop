<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Финальный макет сайта</title>
    <link rel="stylesheet" href="/CSS/Style.css">
  </head>
  <body>
   <header>
     <div>
     <nav>
       <ul>
         <li><a href="/main">Главная</a></li>
         <li><a href="/catalog">Каталог</a></li>
         <li><a href="/basket">Корзина<span>
              <i id="basket"><?php echo Basket::getCount();?></i> товар(ов)<span></a></li>
         <li><a href=<?=View::$login_url?>><?=View::$login_detect?><span><?= View::$enter?></span></a></li>
         <li><a href="/register">Регистрация</a></li>
       </ul>
     </nav>
     <h1>Главный заголовок</h1>
    </div>
   </header>
   <aside class="LeftSidebar">
     <nav>
       <ul>
         <li><a href=<?=View::$user_url?>><?=View::$user_panel?></a></li>
       </ul>
     </nav>
     <article class="LeftPoster">
       <h3>Некое обьявление</h3>
       <p>Содержание</p>
     </article>
   </aside>
   <aside class="RightSidebar">
     <article class="RightPoster">
       <h3>Статья некой новости</h3>
       <p>Содержимое статьи</p>
     </article>
   </aside>
   <main>
     <div class="Content">
       <?php
            include './'. $content_view;
      ?>
     </div>
   </main>
   <footer>
     <address class="contacts">
       <a href="#">Контакты</a>
     </address>
     <p>Благодарим за посещение нашего сайта</p>
     <p>&copy;Все права защищены</p>
   </footer>
  </body>
</html>
