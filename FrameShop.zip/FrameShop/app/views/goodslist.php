<h2>Список товаров</h2>
<a href="/admin">назад</a>
<div class="List">
  <li><span>Номер товара</span><span>Наиме&#8203;нование</span><span>Цена</span><span>Колчес&#8203;тво</span></li>
  <?php echo $data ?>
</div>
<nav class="NavBuilder">
  <ul>
    <?=$links['nav']?>
  </ul>
</nav>
<script type="text/javascript" src="/../Js/goods.js"></script>
