<h2>Список заказов</h2>
<a href="/admin/">назад</a>
<div class="List">
  <li><span>Номер заказа</span><span>Наиме&#8203;нование</span><span>Количес&#8203;тво</span><span>Заказчик</span></li>
  <?php
   echo $data;
   ?>
</div>
