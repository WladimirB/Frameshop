<h2><?php echo $data ?></h2>
<form class="register" name="register" enctype="multipart/form-data" action="/register/post"  method="post">
  <span></span>
  <input type="text" name="login" placeholder="введите логин">
  <span></span>
  <input type="text" name="password" placeholder="ведите пароль">
  <span></span>
  <input type="email" name="email" placeholder="ваш почтовый ящик">
  <span></span>
  <input type="submit" name="submit" value="регистрация">
  <span></span>
</form>
<script src="./js/form.js">

</script>
