<h2>Страница товара <?=$data['id']?></h2>
<a href="/catalog/getLinks/<?=$data['page']?>">Назад</a>

<div class="Product">
<img src="<?=FileManager::createSrc($data['image'],0)?>" alt="<?=$data['image']?>">
<p>Модель:<?=$data['name'] ?></p>
<p>Цена: <?=$data['price'] ?></p>
<div>
<?php if(is_array($data['info'])){ for($i=0,$size=count($data['info']);$i<$size;$i++):?>
   <span><?=$data['info'][$i]?></span>
 <?php endfor;}
  else{?>
     <span><?=$data['info']?></span>
   <?php }?>
</div>
<a data-action="addToBasket" id="<?= $data['id']?>" href="#">В корзину</a>
</div>
<script type="text/javascript" src="/Js/basket.js"></script>
