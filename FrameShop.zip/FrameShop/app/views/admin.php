<h2>Вы вошли как админ-id:<?php echo $data ?></h2>
<div class="List">
  <nav>
  <ul>
    <li><a href="/admin/list/1">Список товаров</a></li>
    <li><a href="/admin/orders">Список заказов</a></li>
    <li><a href="/admin/add">Добавить товар</a></li>
    <li><a href="/admin/logout">Выход</a></li>
  </ul>
  </nav>
  <hr>
</div>
