<h2>Ответ сервера</h2>

<div class="List">
  <p><?php echo $data ?><p>
</div>
