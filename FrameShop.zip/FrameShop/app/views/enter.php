<h2>Вход</h2>
<form class="register" action="/enter/post" method="post">
  <span></span>
  <input type="text" name="login" placeholder="ваш логин">
  <span></span>
  <input type="password" name="password" placeholder="пароль">
  <span></span>
  <input type="submit" name="submit" value="войти">
  <span></span>
</form>
