<?php
// подключаем файлы ядра
include 'config/form_settings.php';
require_once 'core/navbuilder.php';
require_once 'core/dbconnect.php';
require_once 'core/image.php';
require_once 'core/model.php';
require_once 'core/view.php';
require_once 'core/controller.php';
require_once 'core/form_validator.php';
require_once 'core/basket.php';


/*
Здесь обычно подключаются дополнительные модули, реализующие различный функционал:
	> аутентификацию
	> кеширование
	> работу с формами
	> абстракции для доступа к данным
	> ORM
	> Unit тестирование
	> Benchmarking
	> Работу с изображениями
	> Backup
	> и др.
*/

require_once 'core/router.php';
Router::start(); // запускаем маршрутизатор
