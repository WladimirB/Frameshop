<?php
 define('HOST','127.0.0.1');
 define('DATABASE','frameshop');
 define('USER','root');
 define('PASSWORD','');
