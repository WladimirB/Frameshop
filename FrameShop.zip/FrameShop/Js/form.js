
 let form = document.forms.register;
 form.addEventListener("blur",show,true);


 function getData(input){
  let data ={};
  data[input.name]=input.value;
  return data;
  }

  function getResponse(response){
    let data = JSON.parse(response);
    let elem = Object.keys(data)[0];
    let target = form.elements[elem].previousElementSibling;
    target.innerHTML = data[elem];
  }


function show(e=event){
  let input = e.target;
  let req=getData(input);
  let json = JSON.stringify(req);

  let xhr = new XMLHttpRequest();
  let url = 'http://frameshop/register/ajax';

  xhr.open('POST',url,true);
  xhr.setRequestHeader('content-type','application/x-www-form-urlencoded');
  xhr.send('valid='+json);

  xhr.onload = function(){
  if(xhr.status != 200){
    console.log(xhr.status +':' + xhr.ststusText );
  }

  else {
    console.log(xhr.response);
    getResponse(xhr.response);
  }
 }
}
