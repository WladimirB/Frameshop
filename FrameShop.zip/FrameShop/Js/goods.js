
let list = document.querySelector('.List');

class HandlerGoods {
  constructor(elem) {
    this._elem = elem;
    elem.onclick = this.onClick.bind(this);
  }

  delete(id) {
    let res=confirm('Подтвердите удаление');
    if(res){
    console.log('удаляю '+id);
    let li = document.getElementById(id);
    let data = id;
    let response = new Transfer('http://frameshop/admin/ajax',data);
    response.send(function(arg,elem=li){li.innerHTML=arg},'delete');
    }
  }

  update(id) {
    let li = document.getElementById(id);
    let before = li.cloneNode(true);
    let arr = Array.from(li.getElementsByTagName('span'));
    let data ={};
    arr.map(item =>
                   { data[item.getAttribute('name')] = item.textContent });

     li.innerHTML='';
     let form = new FormUpdate(data,li).create();

    let update={};//обьект для отправки с измененными данными

   /* при изменени данных формы сравниваем их певвоначальными данными и формируем запррс */
    form.onchange = (e)=>{
      let elem = e.target;
      if(data[elem.name]!=elem.value){
      update[elem.name]=elem.value;
      }
    }

    function isEmpty(obj){
      for(let key in obj){
        return false;
      }
      return true;
    }

    form.onsubmit = (e) =>{
        e.preventDefault();
        if(isEmpty(update)){li.replaceWith(before);return;}
        update['id']=id;
        console.log(update);
        let request=JSON.stringify(update);
        let response = new Transfer('http://frameshop/admin/ajax',request);

    response.send(function(arg,elem=li){
          elem.replaceWith(arg);
        },'update');
      };
 }

  onClick(event) {
    let target = event.target;
    let action = target.dataset.action;
    let id = target.closest('li').getAttribute('id');
    if(action){
      this[action](id);
    }
  };
}

class Transfer {
  constructor(url,data) {
    this._url = url;
    this._data = data;
    }

    send(callback,action=null){
    let xhr = new XMLHttpRequest();
    xhr.open('POST',this._url,true);
    xhr.setRequestHeader('content-type','application/x-www-form-urlencoded');
    if(this.action !== null){
    xhr.setRequestHeader('admin',''+action);}
    xhr.onload =function(){
                  console.log(`Загружено: ${xhr.status} ${xhr.response}`);
                }
    xhr.onerror = function(){
      alert(`Ошибка соединения`);
    };
    xhr.onloadend = function(){
      if(xhr.status == 200 && xhr.readyState == 4){
       callback(xhr.response);
      }
    }
    xhr.send('data='+this._data);
   }
}

class FormUpdate{
 constructor(data,target) {
   this._data=data;
   this._target=target;
   }

  create(){
    const form = document.createElement('form');

    const input = (type,name,value) => {
    let input=document.createElement('input');
    input.type=(name =='submit')?type:
               (Number(value))?type:'text';
    input.name=name;
    input.value=value;
    return input;
  };

  Object.entries(this._data).map(([name,value])=>{
    form.append(input('number',name,value));
  });

  form.append(input('submit','submit','Готово!'));
   form.elements[0].setAttribute('readonly','');
  this._target.append(form);
  return form;
 }

}

new HandlerGoods(list);
