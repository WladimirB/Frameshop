let goods_container = document.querySelector('.Content');

class Basket{
  constructor(elem)
  {
    this._elem=elem;
    elem.onclick=this.onClick.bind(this);
  }

  addToBasket(id){
    console.log('Консоль id'+id);
    let url = 'http://frameshop/basket/ajax'
    let ajax=new Transfer(url,id);
    let display=document.getElementById('basket');
    ajax.send(() =>{
                     display.innerText=parseInt(display.innerText)+1});
  }

  onClick(event){
    let target = event.target;
    let action = target.dataset.action;
    let id = target.getAttribute('id');
    if (action){
      this[action](id);
    }
  };
}

new Basket(goods_container);

class Transfer{
  constructor(url,data){
    this._url=url;
    this._data=data;
  }

  send(callback){
    let xhr = new XMLHttpRequest();
    xhr.open('POST',this._url,true);
    xhr.setRequestHeader('content-type','application/x-www-form-urlencoded');
    xhr.onload = function(){
      console.log(`Загружено ${xhr.status}:${xhr.response}`);
      callback(xhr.response);
    }
    xhr.send('data='+this._data)
  }

}
